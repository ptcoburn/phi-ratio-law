# Single-state φ-ratio convergence demo
import numpy as np
import matplotlib.pyplot as plt

phi = (1 + 5**0.5) / 2  # golden ratio
psi = 1 / phi           # proportional gain ~ critical damping for this update

x = np.random.uniform(0.5, 2.5)  # initial state
threshold = 0.003
history = [x]

for t in range(100):
    x = x + psi * (phi - x)
    history.append(x)
    if abs(x - phi) < threshold:
        break

print(f\"Converged to {x:.4f} in {len(history)-1} steps (threshold={threshold})\")


plt.figure()
plt.plot(history, marker='o')
plt.axhline(phi, linestyle='--', label=f\"phi={phi:.6f}\")
plt.xlabel(\"iteration\")
plt.ylabel(\"x\")
plt.title(\"Single-state φ-ratio convergence with ψ=1/φ\")
plt.legend()
plt.tight_layout()
plt.show()
