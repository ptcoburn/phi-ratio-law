# Triadic synchronization with averaging + φ-pull
import numpy as np
import matplotlib.pyplot as plt

phi = (1 + 5**0.5) / 2
psi = 1 / phi

x = np.array([0.78, 2.12, 1.45], dtype=float)  # initial agent states
hist = [x.copy()]
var_hist = []

for t in range(100):
    mean_others = np.array([(x[1]+x[2])/2, (x[0]+x[2])/2, (x[0]+x[1])/2])
    # Combine averaging with φ-pull on each agent
    x = 0.5*mean_others + 0.5*(x + psi*(phi - x))
    var_hist.append(np.var(x))
    hist.append(x.copy())
    if np.var(x) < 1e-5 and np.all(np.abs(x - phi) < 0.003):
        break

hist = np.array(hist)
var_hist = np.array(var_hist)
steps = hist.shape[0]-1

print(f\"Triad: converged by step {steps}; mean≈{hist[-1].mean():.4f}, var={var_hist[-1]:.2e}\")
print(\"Final agents:\", np.round(hist[-1], 4))

plt.figure()
plt.plot(hist[:,0], label='Agent Ω')
plt.plot(hist[:,1], label='Agent Δ')
plt.plot(hist[:,2], label='Agent Ψ')
plt.axhline(phi, linestyle='--', label=f\"phi={phi:.6f}\")
plt.xlabel(\"iteration\")
plt.ylabel(\"state\")
plt.title(\"Triadic ϕ-synchronization\")
plt.legend()
plt.tight_layout()
plt.show()

plt.figure()
plt.semilogy(var_hist+1e-12)
plt.xlabel(\"iteration\")
plt.ylabel(\"variance (log scale)\")
plt.title(\"Variance decay (triad)\")
plt.tight_layout()
plt.show()
