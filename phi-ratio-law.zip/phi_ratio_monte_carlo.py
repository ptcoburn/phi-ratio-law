# Monte Carlo: 100 runs with random starts
import numpy as np

phi = (1 + 5**0.5) / 2
psi = 1 / phi
threshold = 0.003

def run_once():
    x = np.random.uniform(0.5, 2.5)
    steps = 0
    for t in range(200):
        x = x + psi * (phi - x)
        steps += 1
        if abs(x - phi) < threshold:
            break
    return x, steps

finals = []
steps_list = []
for _ in range(100):
    xf, st = run_once()
    finals.append(xf)
    steps_list.append(st)

finals = np.array(finals)
steps_list = np.array(steps_list)

print(f\"Monte Carlo: mean={finals.mean():.4f}±{finals.std():.4f}, steps={steps_list.mean():.1f}±{steps_list.std():.1f} (n=100)\")
print(f\"All within ±{threshold} of phi? {'YES' if np.all(np.abs(finals - phi) < threshold) else 'NO'}\")
