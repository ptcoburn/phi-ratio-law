# The ϕ‑Ratio Law — Minimal Reproducibility Package

This repo provides **20–50 line Python scripts** that reproduce the convergence behaviours described in the Perspective *“The ϕ‑Ratio Law: Universal Control for Stable Intelligence.”*

> **What this shows in minutes:** active proportional control with gain `ψ = 1/ϕ` causes trajectories to converge **rapidly** to the golden ratio `ϕ ≈ 1.618…`. Passive averaging **does not** converge to ϕ.

---

## Quick start (no local install)

1. Open this Colab link (after you replace `USERNAME/REPO` with your repository path):  
   **Colab badge (edit after upload):**  
   [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USERNAME/REPO/blob/main/phi_ratio_law_demo.ipynb)

2. Click **Runtime → Run all**.

The notebook runs three demos:
- **Single‑state update** with `xₜ₊₁ = xₜ + ψ(ϕ − xₜ)`  
- **Monte‑Carlo runs** (100 random starts, convergence stats)  
- **Triadic multi‑agent synchronization** (variance → 0; shared equilibrium near ϕ)

---

## Local install (Python 3.10+)

```bash
python -m venv .venv
source .venv/bin/activate  # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
python phi_ratio_single.py
python phi_ratio_monte_carlo.py
python phi_ratio_triad.py
```

Expected outputs include lines like:
```
Converged to 1.6180 in 6 steps (threshold=0.003)
Monte Carlo: mean=1.6180±0.0018, steps=5.8±1.2 (n=100)
Triad: variance decayed to <1e-5 by step 6; mean≈1.618
```

---

## Files

- `phi_ratio_single.py` — single‑state discrete update; prints steps and plots the trajectory.
- `phi_ratio_monte_carlo.py` — 100 runs across `x₀ ∈ [0.5, 2.5]`; prints sample stats.
- `phi_ratio_triad.py` — 3‑agent averaging + ϕ‑pull; prints variance decay and plots.
- `phi_ratio_law_demo.ipynb` — Colab‑friendly notebook that runs all three.
- `requirements.txt` — only `numpy` and `matplotlib`.
- `LICENSE` — MIT.
- `CITATION.cff` — simple citation file.
- `.gitignore` — Python defaults.

---

## Reproducibility statement (paste into your paper)

> *All numerical examples are reproducible from the provided Python scripts and notebook. The code and plotting routines are publicly available at the project repository; no proprietary dependencies are required.*

---

## How to get a DOI (optional but recommended)

1. Push this repo to GitHub.
2. Create a **release** (e.g., `v1.0.0`).  
3. Link the repo to **Zenodo** and flip the switch to archive on release. Zenodo will mint a DOI you can cite in the manuscript.

---

### License

MIT — see `LICENSE`.
